<?php

namespace App\Http\Controllers;

use App\Models\Exam;
use App\Models\AcademicSession;
use Illuminate\Http\Request;

class ExamController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:view exams')->only(['index']);
        $this->middleware('permission:create exams')->only(['create', 'store']);
        $this->middleware('permission:edit exams')->only(['edit', 'update']);
        $this->middleware('permission:delete exams')->only(['destroy']);
    }

    /**
     * Display a listing of exams.
     */
    public function index(Request $request)
    {
        $query = Exam::with('academicSession');

        // Optional search by name or term
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('term', 'like', "%{$search}%")
                  ->orWhereHas('academicSession', function($q2) use ($search) {
                      $q2->where('name', 'like', "%{$search}%");
                  });
            });
        }

        $exams = $query->orderBy('id', 'desc')->paginate(10)->withQueryString();

        return view('exams.index', compact('exams'));
    }

    /**
     * Show form to create a new exam.
     */
    public function create()
    {
        $sessions = AcademicSession::all();
        return view('exams.create', compact('sessions'));
    }

    /**
     * Store a newly created exam in database.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'term' => 'required|string|max:50',
            'academic_session_id' => 'required|exists:academic_sessions,id',
        ]);

        $data = $request->only('name', 'term', 'academic_session_id');

        // Handle checkboxes
        $data['include_in_term_final'] = $request->has('include_in_term_final');
        $data['include_in_year_final'] = $request->has('include_in_year_final');
        $data['is_terminal_exam'] = $request->has('is_terminal_exam');
        $data['is_annual_exam'] = $request->has('is_annual_exam'); // new

        Exam::create($data);

        return redirect()->route('exams.index')->with('success', 'Exam created successfully.');
    }

    /**
     * Show form to edit an existing exam.
     */
    public function edit(Exam $exam)
    {
        $sessions = AcademicSession::all();
        return view('exams.edit', compact('exam', 'sessions'));
    }

    /**
     * Update an existing exam.
     */
    public function update(Request $request, Exam $exam)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'term' => 'required|string|max:50',
            'academic_session_id' => 'required|exists:academic_sessions,id',
        ]);

        $data = $request->only('name', 'term', 'academic_session_id');

        // Handle checkboxes
        $data['include_in_term_final'] = $request->has('include_in_term_final');
        $data['include_in_year_final'] = $request->has('include_in_year_final');
        $data['is_terminal_exam'] = $request->has('is_terminal_exam');
        $data['is_annual_exam'] = $request->has('is_annual_exam'); // new

        $exam->update($data);

        return redirect()->route('exams.index')->with('success', 'Exam updated successfully.');
    }

    /**
     * Delete an exam.
     */
    public function destroy(Exam $exam)
    {
        $exam->delete();
        return redirect()->route('exams.index')->with('success', 'Exam deleted successfully.');
    }

    /**
     * AJAX: Get exams for a specific academic session (for dynamic dropdown in marks form)
     */
    public function getExamsBySession(Request $request)
    {
        $request->validate([
            'session_id' => 'required|exists:academic_sessions,id',
        ]);

        $exams = Exam::where('academic_session_id', $request->session_id)
            ->orderBy('created_at', 'desc')
            ->get(['id', 'name']);

        return response()->json($exams);
    }
}