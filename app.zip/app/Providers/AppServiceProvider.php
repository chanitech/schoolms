<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;
use Spatie\Permission\Middlewares\RoleMiddleware;
use Illuminate\Database\Eloquent\Relations\Relation;
use App\Models\Student;
use App\Models\Staff;
use App\Models\User;
use App\Models\Invoice;
use App\Models\Budget;
use Illuminate\Support\Facades\View;


class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
       // Relation::enforceMorphMap([
       // 'user' => User::class,     // 👈 add this line
        //'student' => Student::class,
        //'staff' => Staff::class,
    //]);

    View::composer('vendor.adminlte.partials.sidebar.menu', function ($view) {
        $pendingInvoicesCount = Invoice::where('status', 'pending')->count();
        $view->with('pendingInvoicesCount', $pendingInvoicesCount);
    });

    View::composer('vendor.adminlte.partials.sidebar.menu', function ($view) {
        $pendingBudgetsCount = Budget::where('status', 'pending')
            ->where('current_step', 'do')
            ->count();
        $view->with('pendingBudgetsCount', $pendingBudgetsCount);
    });
    }
}
